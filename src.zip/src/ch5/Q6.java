package ch5;
// 적절한 한 줄의 코드를 작성하
public class Q6 {
	class TV {
		private int size;
		public TV(int n) {size = n;}
	}
	class colorTV extends TV {
		private int colors;
		public colorTV(int colors, int size) {
			super(size);
			this.colors = colors;
		}
	}
}
