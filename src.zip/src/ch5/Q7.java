package ch5;
// 상속에 있어 생성자에 대해 묻는 문제. 실행될 때 출력되는 내용은 무엇인가?
class A {
	public A() { System.out.println("A"); }
	public A(int x) { System.out.println("A:" + x); }
}
class B extends A {
	public B() { super(100); }
	public B(int x) { System.out.println("B:" + x); }
}
public class Q7 {
	public static void main(String[] args) {
		B b = new B(11);
	}
}
// 출력결과 
// A
// B:11