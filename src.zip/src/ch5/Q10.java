package ch5;

abstract class OddDetector {
	protected int n;
	public OddDetector (int n) {
		this.n = n;
	}
}
public class Q10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
