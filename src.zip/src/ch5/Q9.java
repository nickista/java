package ch5;
// 다음 추상 클래스의 선언이나 사용이 잘못된 것을 있는 대로 가려내고 오류를 지적 
// 1.
abstract class A {	// <- f()는 구현이 안 되어있고 선언만 됐기 때문에 추상 메서드여야 한다. abstract 추가 
	void f();
}
// 2.
abstract class A {
	 void f() { // <- f() 가 선언 및 구현 되어있으므로 수정할 필요 없음. 
		System.out.println("~");
	}
}
// 3.
abstract class B {
	abstract void f(); 
}
class C extends B { // B와 f가 추상 메서드이기 때문에 밑에도 abstract를 써야 한다. 
	@Override
	void f() {
		
	}
}

// 4.
abstract class B {
	abstract int f();
}
class C extends B {
	void f() {
		System.out.println("~");
		return 0; // int로 선언하였으나 int로 반환하지 않았으므로 리턴을 해줘야 함. 
	}
}
public class Q9 {

}
