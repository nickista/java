package ch5;
// 생성자로 인한 오류 찾기, 이유를 설명, 오류를 수정 
class A {
	private int a;
	protected A(int i) {
		a = i;
	}
	}
}
class B extends A {
	private int b;
	public B() {
		super(0);
		b = 0;
	}
}
public class Q8 {
	
}
// 오류 찾기 및 이유 : B 클래스의 기본 생성자가 부모 클래스 A의 생성자를 호출하지 않기 때문
// 오류 수정 : super(0)을 추가하여 부모 클래스의 생성자를 호츌 