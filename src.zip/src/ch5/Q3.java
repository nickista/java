package ch5;
// 상속을 이용하여 다음 클래스들을 간결한 구조로 재작성하라.
/*
class SharpPencil {
	private int width; // 펜의 굵기
	private int amount; // 남은 량
	public int getAmount() { return amount; }
	public void setAmount(int amount) { this.amount = amount; }
}
class Ballpen { // 볼펜
	private int amount; // 남은 량
	private String color; // 볼펜의 색
	public int getAmount() { return amount; }
	public void setAmount(int amount) { this.amount = amount; }
	public String getColor() { return color; }
	public void setColor(String color) { this.color = color; }
}
*/

class FountainPen { // 만년
	private int amount;
}

class WritingInstrument {
    private int amount; // 남은 량
    
    public int getAmount() {
        return amount;
    }
    
    public void setAmount(int amount) {
        this.amount = amount;
    }
}

class SharpPencil extends WritingInstrument {
    private int width; // 펜의 굵기

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }
}

class Ballpen extends WritingInstrument {
    private String color; // 볼펜의 색
    
    public String getColor() {
        return color;
    }
    
    public void setColor(String color) {
        this.color = color;
    }
}

class FountainPen extends WritingInstrument {
    // 추가 필드가 없으므로 `WritingInstrument`의 기능만 사용
}

public class Q3 {

}

// Q4. 다음 중 적절한 단어를 기입하라.
// 상속받는 클래스 : 자식
// 상속 선언 키워드 : extends
// 객체가 어떤 클래스의 타입인지 알아내는 키워드 : instanceof
// 인터페이스가 선언하는 키워드 : interface 

// Q5. 상속에 관련된 접근 지정자에 대한 설명이다. 틀린 것은? : 2
