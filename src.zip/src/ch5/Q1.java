package ch5;
// 다음 클래스에 답하라. 객체 멤버 나열
class A {
	private int a;
	public void set(int a) { this.a = a; }
}
class B extends A {
	protected int b, c;
}
class C extends B {
	public int d, e;
}
// 클래스 D를 작성했을 때 오류가 발생하는 라인 : 16(a = 1;)
class D extends C {
	public void f() {
		a = 1;
		set(10);
		b = 20;
		d = 30;
	}
}

public class Q1 {
	public static void main(String[] args) {
		A objA = new A();
		B objB = new B();
		C objC = new C();
	}
}

// 자바의 모든 클래스가 반드시 상속받게 되어 있는 클래스는?
// 1. Object
