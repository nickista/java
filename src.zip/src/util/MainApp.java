package util;
// 이거 어려워서 못했어요
import main.Calc;
public class MainApp extends Calc {

	public static void main(String[] args) {
		public static void main(String[] args) {
			Calc c = new Calc(10, 20);
			System.out.println(c.sum());
		}

	}

}
