package app;

import component.Circle;

public class GraphicEditor extends Circle {

	public static void main(String[] args) {
		Shape shape = new Circle();
		shape.draw();

	}

}
