package Practice08;
// 간단한 파일 탐색기 만들기
import java.io.*;
import java.util.*;

public class Q13 {
    private static File currentDirectory = new File(System.getProperty("user.dir")); // 초기 디렉토리는 현재 작업 디렉토리

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            // 현재 디렉토리 목록 출력
            System.out.println("현재 디렉토리: " + currentDirectory.getAbsolutePath());
            listFilesInDirectory();

            // 사용자 입력 받기
            System.out.print("이동할 폴더나 파일을 입력하세요. (뒤로 가려면 '..' 입력, 종료하려면 'exit'): ");
            String userInput = scanner.nextLine();

            // 'exit' 입력 시 종료
            if (userInput.equalsIgnoreCase("exit")) {
                System.out.println("프로그램을 종료합니다.");
                break;
            }

            // '..' 입력 시 상위 디렉토리로 이동
            if (userInput.equals("..")) {
                currentDirectory = currentDirectory.getParentFile();
                if (currentDirectory == null) {
                    System.out.println("상위 디렉토리가 없습니다.");
                    currentDirectory = new File(System.getProperty("user.dir")); // 다시 초기 디렉토리로 돌아가기
                }
                continue;
            }

            File selectedFile = new File(currentDirectory, userInput);

            // 선택한 것이 디렉토리일 경우 그 디렉토리로 이동
            if (selectedFile.isDirectory()) {
                currentDirectory = selectedFile;
            } else if (selectedFile.isFile()) {
                // 파일인 경우 파일 내용을 출력
                displayFileContents(selectedFile);
            } else {
                System.out.println("유효하지 않은 입력입니다.");
            }
        }

        scanner.close();
    }

    // 디렉토리 내의 파일 및 폴더 목록 출력
    private static void listFilesInDirectory() {
        File[] files = currentDirectory.listFiles();
        if (files != null && files.length > 0) {
            System.out.println("파일/폴더 목록:");
            for (File file : files) {
                if (file.isDirectory()) {
                    System.out.println("[DIR] " + file.getName());
                } else {
                    System.out.println("[FILE] " + file.getName());
                }
            }
        } else {
            System.out.println("이 디렉토리에는 파일이나 폴더가 없습니다.");
        }
    }

    // 파일 내용을 출력
    private static void displayFileContents(File file) {
        if (file.exists() && file.isFile()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                System.out.println("파일 내용:");
                while ((line = reader.readLine()) != null) {
                    System.out.println(line);
                }
            } catch (IOException e) {
                System.out.println("파일을 읽는 데 오류가 발생했습니다: " + e.getMessage());
            }
        } else {
            System.out.println("파일을 찾을 수 없습니다.");
        }
    }
}
