package Practice08;
// 바이너리 파일 복사 연습 
import java.io.*;

public class Q7 {
    public static void main(String[] args) {
        // 원본 및 복사본 파일 이름
        String sourceFileName = "appleLogoScreenshot.png";
        String destinationFileName = "appleLogoScreenshot.png2";

        // 파일 복사 진행
        try (
            InputStream inputStream = Q7.class.getResourceAsStream(sourceFileName);
            OutputStream outputStream = new FileOutputStream(destinationFileName)
        ) {
            if (inputStream == null) {
                System.out.println("원본 파일을 찾을 수 없습니다.");
                return;
            }

            // 파일 크기를 가져옴
            File sourceFile = new File(Q7.class.getResource(sourceFileName).getFile());
            long fileSize = sourceFile.length();
            byte[] buffer = new byte[1024]; // 1KB 버퍼
            long totalBytesRead = 0;
            int bytesRead;
            int progressThreshold = (int) (fileSize / 10); // 10% 단위
            long nextProgress = progressThreshold;

            System.out.println(sourceFileName + "를 " + destinationFileName + "로 복사합니다.");
            System.out.println("10%마다 *를 출력합니다.");

            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
                totalBytesRead += bytesRead;

                // 진행 상황 체크 및 '*' 출력
                if (totalBytesRead >= nextProgress) {
                    System.out.print("*");
                    nextProgress += progressThreshold;
                }
            }

            System.out.println("\n복사가 완료되었습니다.");
        } catch (IOException e) {
            System.out.println("파일 복사 중 오류가 발생했습니다: " + e.getMessage());
        }
    }
}
