package Practice08;
// 행맨 게임하기 
import java.io.*;
import java.util.*;

public class CodingChallenge08 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<String> words = loadWords("/Users/yeongtaekkim/Desktop/2학기 수업자료/자바프로그래밍/words10.txt");
        Random random = new Random();
        boolean continuePlaying = true;

        System.out.println("지금부터 행맨 게임을 시작합니다.");

        while (continuePlaying) {
            String word = words.get(random.nextInt(words.size())); // 랜덤 단어 선택
            char[] hiddenWord = hideLetters(word); // 일부 문자 숨기기
            int failCount = 0;

            while (true) {
                System.out.println(new String(hiddenWord));
                System.out.print(">> ");
                char guess = scanner.nextLine().charAt(0);

                boolean correct = false;

                for (int i = 0; i < word.length(); i++) {
                    if (hiddenWord[i] == '-' && word.charAt(i) == guess) {
                        hiddenWord[i] = guess;
                        correct = true;
                    }
                }

                if (!correct) {
                    failCount++;
                    System.out.println("틀렸습니다! 현재 실패 횟수: " + failCount);
                }

                if (failCount == 5) {
                    System.out.println("5번 실패하였습니다.");
                    break;
                }

                if (new String(hiddenWord).equals(word)) {
                    System.out.println(word);
                    break;
                }
            }

            System.out.print("Next(y/n)? ");
            String response = scanner.nextLine();
            continuePlaying = response.equalsIgnoreCase("y");
        }

        System.out.println("종료합니다.");
        scanner.close();
    }

    // words.txt 파일에서 단어를 읽어 리스트로 반환
    public static List<String> loadWords(String filename) {
        List<String> words = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                words.add(line.trim());
            }
        } catch (IOException e) {
            System.err.println("파일을 읽을 수 없습니다: " + e.getMessage());
        }
        return words;
    }

    // 단어에서 두 글자를 숨긴 배열 반환
    public static char[] hideLetters(String word) {
        Random random = new Random();
        char[] hiddenWord = word.toCharArray();
        Set<Integer> hiddenIndices = new HashSet<>();

        while (hiddenIndices.size() < 2) {
            int index = random.nextInt(word.length());
            hiddenIndices.add(index);
        }

        for (int index : hiddenIndices) {
            hiddenWord[index] = '-';
        }

        return hiddenWord;
    }
}

