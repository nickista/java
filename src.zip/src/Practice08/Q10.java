package Practice08;
// 전화번호 리스트를 읽고 이름을 출력하면 전화번호를 표시해주는 프로그램 
import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Q10 {
    public static void main(String[] args) {
        // 이름과 전화번호를 저장할 Map 생성
        Map<String, String> phoneBook = new HashMap<>();
        
        // 외부 파일 경로 지정 (파일 경로에서 불필요한 따옴표 제거)
        File file = new File("/Users/yeongtaekkim/Desktop/2학기 수업자료/자바프로그래밍/PhoneNum.txt");

        // rtf 파일에서 데이터를 읽어와 Map에 저장
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // 줄에서 이름과 전화번호 분리
                String[] parts = line.split(" ");
                if (parts.length == 2) {
                    phoneBook.put(parts[0], parts[1]);
                }
            }
            System.out.println("총 " + phoneBook.size() + "개의 전화번호를 읽었습니다.");
        } catch (IOException e) {
            System.out.println("파일을 읽는 중 오류가 발생했습니다: " + e.getMessage());
            return;
        }

        // 사용자 입력을 받기 위한 Scanner 생성
        Scanner scanner = new Scanner(System.in);
        String name;

        while (true) {
            System.out.print("이름>> ");
            name = scanner.nextLine();

            if (name.equals("그만")) {
                System.out.println("프로그램을 종료합니다.");
                break;
            }

            // 전화번호 출력
            if (phoneBook.containsKey(name)) {
                System.out.println(phoneBook.get(name));
            } else {
                System.out.println("해당 이름의 전화번호가 없습니다.");
            }
        }

        scanner.close();
    }
}
