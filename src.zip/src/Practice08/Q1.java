package Practice08;

import java.io.*;
import java.util.Scanner;

public class Q1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String fileName = "/Users/yeongtaekkim/Desktop/2학기 수업자료/자바프로그래밍/phone.rtf"; // 경로 설정
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {
            System.out.println("전화번호 입력 프로그램입니다.");
            
            while (true) {
                System.out.print("이름 전화번호 >> ");
                String input = scanner.nextLine();
                
                if (input.equals("그만")) {
                    break;  // "그만"을 입력하면 종료
                }
                
                // 입력받은 내용이 두 부분으로 나누어져 있는지 확인
                String[] parts = input.split(" ");
                
                if (parts.length == 2) {
                    String name = parts[0];  // 이름
                    String phoneNumber = parts[1];  // 전화번호
                    
                    // 파일에 저장
                    writer.write(name + " " + phoneNumber);
                    writer.newLine();  // 각 기록을 새로운 줄로 저장
                } else {
                    System.out.println("잘못된 형식입니다. 다시 입력하세요.");
                }
            }
            
            System.out.println("'" + fileName + "'에 저장하였습니다.");
        } catch (IOException e) {
            System.out.println("파일을 작성하는 중 오류가 발생했습니다: " + e.getMessage());
        } finally {
            scanner.close();  // Scanner 종료
        }
    }
}

