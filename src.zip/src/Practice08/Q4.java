package Practice08;
//파일을 읽고 라인마다 번호를 붙여 출력 
import java.io.*;
import java.util.Scanner;

public class Q4 {
    public static void main(String[] args) {
        try {
            // 파일을 읽기 위해 Scanner 객체 생성
            Scanner fScanner = new Scanner(new FileReader("/Users/yeongtaekkim/Desktop/system.rtf"));

            int lineNumber = 1; // 라인 번호를 초기화
            while (fScanner.hasNextLine()) { // 파일에 읽을 내용이 있는 동안
                String line = fScanner.nextLine(); // 파일에서 한 라인 읽기
                System.out.printf("%d: %s%n", lineNumber, line); // 라인 번호와 함께 출력
                lineNumber++; // 라인 번호 증가
            }

            fScanner.close(); // Scanner 객체 닫기
        } catch (FileNotFoundException e) {
            System.out.println("파일을 찾을 수 없습니다: " + e.getMessage());
        }
    }
}
