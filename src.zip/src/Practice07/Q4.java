package Practice07;

import java.util.HashMap;
import java.util.Scanner;

public class Q4 {
    public static void main(String[] args) {
        // 구입 가능한 물건과 가격을 저장한 HashMap 생성
        HashMap<String, Integer> items = new HashMap<>();
        items.put("고추장", 3000);
        items.put("만두", 500);
        items.put("새우깡", 1500);
        items.put("콜라", 600);
        items.put("참치캔", 2000);
        items.put("치약", 1000);
        items.put("연어", 2500);
        items.put("삼겹살", 2500);

        Scanner scanner = new Scanner(System.in);
        System.out.println("쇼핑 비용을 계산해드립니다. 구입 가능 물건과 가격은 다음과 같습니다.");
        items.forEach((key, value) -> System.out.println("[" + key + ", " + value + "]"));

        while (true) {
            System.out.print("물건과 개수를 입력하세요>> ");
            String input = scanner.nextLine();

            if (input.equals("그만")) {
                break;
            }

            String[] tokens = input.split(" ");
            int totalCost = 0;
            boolean validInput = true;

            for (int i = 0; i < tokens.length; i += 2) {
                if (i + 1 >= tokens.length) {
                    System.out.println("입력에 문제가 있습니다!");
                    validInput = false;
                    break;
                }

                String item = tokens[i];
                int quantity;
                try {
                    quantity = Integer.parseInt(tokens[i + 1]);
                } catch (NumberFormatException e) {
                    System.out.println("입력에 문제가 있습니다!");
                    validInput = false;
                    break;
                }

                if (!items.containsKey(item)) {
                    System.out.println(item + "은(는) 없는 상품입니다!");
                    validInput = false;
                    break;
                }

                totalCost += items.get(item) * quantity;
            }

            if (validInput) {
                System.out.println("전체 비용은 " + totalCost + "원입니다.");
            }
        }

        scanner.close();
    }
}

