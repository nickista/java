package Practice07;
// 퀴즈 프로그램 영단어 
import java.util.*;

class Word {
    String word;     // 영어 단어
    String meaning;  // 뜻 (정답)
    
    // 생성자
    public Word(String word, String meaning) {
        this.word = word;
        this.meaning = meaning;
    }
    
    // getter
    public String getWord() {
        return word;
    }
    
    public String getMeaning() {
        return meaning;
    }
}

public class CodingChallenge07 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Vector<Word> v = new Vector<>();
        
        // 17개의 단어를 추가
        v.add(new Word("painting", "그림"));
        v.add(new Word("picture", "사진"));
        v.add(new Word("human", "인간"));
        v.add(new Word("tree", "나무"));
        v.add(new Word("book", "책"));
        v.add(new Word("dog", "개"));
        v.add(new Word("cat", "고양이"));
        v.add(new Word("house", "집"));
        v.add(new Word("computer", "컴퓨터"));
        v.add(new Word("apple", "사과"));
        v.add(new Word("school", "학교"));
        v.add(new Word("student", "학생"));
        v.add(new Word("teacher", "선생님"));
        v.add(new Word("car", "차"));
        v.add(new Word("flower", "꽃"));
        v.add(new Word("city", "도시"));
        v.add(new Word("river", "강"));
        
        // 퀴즈 시작
        System.out.println("\"명품영어\"의 단어 테스트를 시작합니다. -1을 누르면 종료합니다.");
        System.out.println("현재 " + v.size() + "개의 단어가 들어 있습니다.");

        Random rand = new Random();
        while (true) {
            // 랜덤으로 단어 하나 선택
            int index = rand.nextInt(v.size());
            Word currentWord = v.get(index);
            String correctAnswer = currentWord.getMeaning();

            // 보기 선택
            Set<String> options = new HashSet<>();
            options.add(correctAnswer); // 정답 추가
            while (options.size() < 4) { // 4개의 보기 만들기
                int wrongIndex = rand.nextInt(v.size());
                String wrongAnswer = v.get(wrongIndex).getMeaning();
                options.add(wrongAnswer);
            }
            
            // 보기 순서 섞기
            List<String> optionsList = new ArrayList<>(options);
            Collections.shuffle(optionsList);
            
            // 보기 출력
            System.out.println(currentWord.getWord() + "?");
            for (int i = 0; i < optionsList.size(); i++) {
                System.out.println("(" + (i+1) + ")" + optionsList.get(i));
            }
            
            // 답 입력 받기
            System.out.print(":>");
            int answer = scanner.nextInt();
            
            // 종료 조건
            if (answer == -1) {
                System.out.println("\"명품영어\"를 종료합니다.");
                break;
            }
            
            // 정답 체크
            String selectedAnswer = optionsList.get(answer - 1);
            if (selectedAnswer.equals(correctAnswer)) {
                System.out.println("Excellent!!");
            } else {
                System.out.println("No!");
            }
        }
        
        scanner.close();  // Scanner 종료
    }
}
