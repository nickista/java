package Practice07;
// 중복 문자열을 제거하고 출력하는 프로그램 
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class Q10 {
	    public static void main(String[] args) {
	        // 사용자로부터 입력을 받기 위한 Scanner 객체 생성
	        Scanner scanner = new Scanner(System.in);

	        while (true) {
	            // 사용자로부터 한 라인을 입력 받음
	            System.out.println("문자열들을 입력하세요>>");
	            String inputLine = scanner.nextLine();

	            // "그만"이 입력되면 프로그램 종료
	            if (inputLine.equals("그만")) {
	                System.out.println("프로그램을 종료합니다.");
	                break;
	            }

	            // 공백을 기준으로 입력을 나누어 ArrayList에 저장
	            String[] words = inputLine.split("\\s+");
	            List<String> wordList = new ArrayList<>();
	            for (String word : words) {
	                wordList.add(word);
	            }

	            // HashSet을 이용하여 중복된 문자열 제거
	            Set<String> uniqueWords = new HashSet<>(wordList);

	            // 중복이 제거된 단어들을 출력
	            System.out.println(String.join(" ", uniqueWords));
	        }

	        scanner.close();  // Scanner 종료
	    }
	}


