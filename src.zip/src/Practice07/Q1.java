package Practice07;
// 백터를 검색하여 가장 작은 수를 출력하는 프로그램. 
import java.util.Scanner;
import java.util.Vector;

public class Q1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Vector<Integer> numbers = new Vector<>();

        System.out.println("정수 입력(-1이면 끝)>>");
        while (true) {
            int num = scanner.nextInt();
            if (num == -1) {
                break;
            }
            if (num > 0) {
                numbers.add(num);
            }
        }

        if (!numbers.isEmpty()) {
            int smallest = numbers.get(0);
            for (int number : numbers) {
                if (number < smallest) {
                    smallest = number;
                }
            }
            System.out.println("제일 작은 수는 " + smallest);
        } else {
            System.out.println("입력된 양의 정수가 없습니다.");
        }

        scanner.close();
    }
}
