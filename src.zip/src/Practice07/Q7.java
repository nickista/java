package Practice07;

public class Q7 {

}
