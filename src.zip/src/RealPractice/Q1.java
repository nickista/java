package RealPractice;
// StudentApp 클래스를 작성 
class Student {
    String name;
    int age;

    // 생성자
    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // equals() 메서드 재정의 - age 필드가 다르면 다른 학생으로 간주
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Student student = (Student) obj;
        return this.age == student.age; // 학번(age)을 비교
    }

    // toString() 메서드 재정의 - 출력 형식 지정
    @Override
    public String toString() {
        return "학번이 " + age + "인 " + name;
    }
}

public class Q1 {
    public static void main(String[] args) {
        Student a = new Student("황기태", 23); // 학번이 23인 황기태 학생
        Student b = new Student("황기태", 77); // 학번이 77인 황기태 학생
        System.out.println(a);
        if (a.equals(b))
            System.out.println("같은 학생입니다.");
        else
            System.out.println("다른 학생입니다.");
    }
}
