package RealPractice;

// Book 클래스 작성
class Book {
    String author;  // 저자
    String title;   // 도서명
    String buyer;   // 구입자

    // 생성자
    public Book(String author, String title, String buyer) {
        this.author = author;
        this.title = title;
        this.buyer = buyer;
    }

    // equals() 메서드 재정의 - 저자와 도서명이 같으면 같은 책으로 판별
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true; // 같은 객체일 경우 true
        if (obj == null || getClass() != obj.getClass()) return false; // null이거나 다른 클래스일 경우 false
        Book book = (Book) obj;
        return author.equals(book.author) && title.equals(book.title); // 저자와 도서명을 비교
    }

    // toString() 메서드 재정의 - 원하는 출력 형식
    @Override
    public String toString() {
        return buyer + "이 구입한 도서: " + author + "의 " + title;
    }
}

// 메인 클래스
public class Q2 {
    public static void main(String[] args) {
        Book a = new Book("황기태", "명품자바", "김하진");
        Book b = new Book("황기태", "명품자바", "하여린");
        System.out.println(a);
        System.out.println(b);
        if (a.equals(b))
            System.out.println("같은 책");
        else
            System.out.println("다른 책");
    }
}
